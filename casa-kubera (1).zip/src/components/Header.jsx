export default function Header() {
  return (
    <header className="bg-sand text-primary p-6">
      <div className="max-w-5xl mx-auto text-center">
        <img src="/logo.png" alt="Casa Kubera" className="h-20 mx-auto mb-4" />
        <h1 className="text-4xl font-serif">Casa Kubera</h1>
        <p className="text-xl mt-2">A luxury beachfront stay for up to 17 guests</p>
      </div>
    </header>
  );
}