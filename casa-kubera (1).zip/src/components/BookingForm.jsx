import { useState } from 'react';

export default function BookingForm() {
  const [guests, setGuests] = useState(1);
  const [dates, setDates] = useState({ checkIn: '', checkOut: '' });
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    const checkInDate = new Date(dates.checkIn);
    const checkOutDate = new Date(dates.checkOut);
    const diff = (checkOutDate - checkInDate) / (1000 * 60 * 60 * 24);

    const inSeason = checkInDate.getMonth() >= 5 && checkOutDate.getMonth() <= 8 && checkOutDate.getDate() <= 7;

    if (diff < 7) {
      setError('Minimum stay is 7 nights.');
    } else if (guests > 17) {
      setError('Maximum occupancy is 17 guests.');
    } else if (!inSeason) {
      setError('Bookings only available June through first weekend of September.');
    } else {
      setError('');
      alert('Booking request submitted!');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow-md max-w-xl mx-auto mt-8 space-y-4">
      <h2 className="text-2xl font-serif text-primary">Request a Booking</h2>

      <div>
        <label className="block">Check-in</label>
        <input type="date" className="w-full border p-2 rounded" onChange={e => setDates({ ...dates, checkIn: e.target.value })} />
      </div>
      <div>
        <label className="block">Check-out</label>
        <input type="date" className="w-full border p-2 rounded" onChange={e => setDates({ ...dates, checkOut: e.target.value })} />
      </div>
      <div>
        <label className="block">Guests</label>
        <input type="number" className="w-full border p-2 rounded" min="1" max="17" value={guests} onChange={e => setGuests(e.target.value)} />
      </div>

      {error && <p className="text-red-500">{error}</p>}

      <button type="submit" className="bg-primary text-white px-4 py-2 rounded hover:bg-accent">
        Submit Request
      </button>
    </form>
  );
}