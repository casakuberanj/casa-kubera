import Header from '../components/Header';
import BookingForm from '../components/BookingForm';

export default function Home() {
  return (
    <div className="bg-sand min-h-screen">
      <Header />
      <section className="p-8">
        <p className="max-w-3xl mx-auto text-center text-lg mb-8">
          Welcome to Casa Kubera — a serene beachfront retreat that sleeps up to 17 guests.
          Book your summer escape today.
        </p>
        <BookingForm />
      </section>
    </div>
  );
}